package br.com.mundohabbo.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.habbohotel.rooms.RoomChatMessageBubbles;
import com.eu.habbo.habbohotel.users.Habbo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PremiarCommand extends Command {

    private static final int CURRENCY_TYPE = 5;

    private static final String[] EVENT_BADGES = {
            "games_lvl1",
            "games_lvl2",
            "games_lvl3",
            "games_lvl4",
            "games_lvl5"
    };

    private static final int[] REWARD_POINTS = {
            10,
            20,
            30,
            40,
            50
    };

    public PremiarCommand(String permission, String[] keys) {
        super(permission, keys);
    }

    public boolean handle(GameClient gameClient, String[] params) throws Exception {

        Habbo staff = gameClient.getHabbo();

        if (staff == null) {
            return true;
        }

        if (staff.getHabboInfo().getRank().getId() < 7) {
            staff.whisper(Emulator.getTexts().getValue("premiar.msg.no_permission"), RoomChatMessageBubbles.ALERT);
            return true;
        }

        if (params.length < 2) {
            staff.whisper(Emulator.getTexts().getValue("premiar.msg.usage"), RoomChatMessageBubbles.ALERT);
            return true;
        }

        String username = params[1];

        Habbo target = Emulator.getGameEnvironment().getHabboManager().getHabbo(username);

        if (target == null) {
            staff.whisper(Emulator.getTexts().getValue("premiar.msg.user_not_found"), RoomChatMessageBubbles.ALERT);
            return true;
        }

        int currentLevel = getCurrentEventLevel(target);
        int nextLevel = currentLevel + 1;

        boolean maxLevel = false;

        if (nextLevel >= EVENT_BADGES.length) {
            nextLevel = EVENT_BADGES.length - 1;
            maxLevel = true;
        }

        String badgeToGive = EVENT_BADGES[nextLevel];
        int pointsToGive = REWARD_POINTS[nextLevel];

        target.givePoints(CURRENCY_TYPE, pointsToGive);

        if (!userHasBadge(target.getHabboInfo().getId(), badgeToGive)) {
            target.addBadge(badgeToGive);
        }

        target.whisper(
                Emulator.getTexts().getValue("premiar.msg.success_user")
                        .replace("%points%", String.valueOf(pointsToGive)),
                RoomChatMessageBubbles.ALERT
        );

        if (maxLevel) {
            staff.whisper(Emulator.getTexts().getValue("premiar.msg.max_badge"), RoomChatMessageBubbles.ALERT);
        }

        staff.whisper(
                Emulator.getTexts().getValue("premiar.msg.success_staff")
                        .replace("%user%", target.getHabboInfo().getUsername()),
                RoomChatMessageBubbles.ALERT
        );

        return true;
    }

    private int getCurrentEventLevel(Habbo habbo) {
        int userId = habbo.getHabboInfo().getId();

        for (int i = EVENT_BADGES.length - 1; i >= 0; i--) {
            if (userHasBadge(userId, EVENT_BADGES[i])) {
                return i;
            }
        }

        return -1;
    }

    private boolean userHasBadge(int userId, String badgeCode) {
        try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT id FROM user_badges WHERE user_id = ? AND badge_code = ? LIMIT 1"
             )) {

            statement.setInt(1, userId);
            statement.setString(2, badgeCode);

            try (ResultSet set = statement.executeQuery()) {
                return set.next();
            }

        } catch (Exception e) {
            Emulator.getLogging().logErrorLine("[PremiarPlugin] Erro ao verificar emblema: " + e.getMessage());
            return false;
        }
    }
}