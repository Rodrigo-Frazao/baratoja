package br.com.mundohabbo;

import br.com.mundohabbo.commands.PremiarCommand;
import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.commands.CommandHandler;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.plugin.EventHandler;
import com.eu.habbo.plugin.EventListener;
import com.eu.habbo.plugin.HabboPlugin;
import com.eu.habbo.plugin.events.emulator.EmulatorLoadedEvent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PremiarPlugin extends HabboPlugin implements EventListener {

    public static PremiarPlugin INSTANCE = null;

    public void onEnable() {
        INSTANCE = this;
        Emulator.getPluginManager().registerEvents(this, this);

        if (Emulator.isReady) {
            checkDatabase();
        }

        Emulator.getLogging().logStart("[PremiarPlugin] Plugin iniciado com sucesso!");
    }

    public void onDisable() {
        Emulator.getLogging().logShutdownLine("[PremiarPlugin] Plugin desligado.");
    }

    @EventHandler
    public static void onEmulatorLoaded(EmulatorLoadedEvent event) {
        INSTANCE.checkDatabase();
    }

    public boolean hasPermission(Habbo habbo, String s) {
        return false;
    }

    private void checkDatabase() {
        boolean reloadPermissions = false;

        Emulator.getTexts().register("commands.description.cmd_premiar", ":premiar <usuario>");
        Emulator.getTexts().register("premiar.cmd_premiar.keys", "premiar");

        Emulator.getTexts().register("premiar.msg.usage", "Use: :premiar <usuario>");
        Emulator.getTexts().register("premiar.msg.no_permission", "Você não tem permissão para usar este comando.");
        Emulator.getTexts().register("premiar.msg.user_not_found", "Usuário não encontrado ou offline.");
        Emulator.getTexts().register("premiar.msg.success_staff", "Você premiou %user% com sucesso.");
        Emulator.getTexts().register("premiar.msg.success_user", "Parabéns! Você venceu um evento e recebeu %points% coroas.");
        Emulator.getTexts().register("premiar.msg.max_badge", "O usuário já está no nível máximo de evento. Coroas entregues normalmente.");

        reloadPermissions = registerPermission("cmd_premiar", "'0', '1'", "0", reloadPermissions);

        if (reloadPermissions) {
            Emulator.getGameEnvironment().getPermissionsManager().reload();
        }

        CommandHandler.addCommand((Command) new PremiarCommand(
                "cmd_premiar",
                Emulator.getTexts().getValue("premiar.cmd_premiar.keys").split(";")
        ));
    }

    private boolean registerPermission(String name, String options, String defaultValue, boolean defaultReturn) {
        try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "ALTER TABLE `permissions` ADD `" + name + "` ENUM(" + options + ") NOT NULL DEFAULT '" + defaultValue + "'"
             )) {
            statement.execute();
            return true;
        } catch (SQLException e) {
            return defaultReturn;
        }
    }

    public static void main(String[] args) {
        System.out.println("Don't run this separately");
    }
}