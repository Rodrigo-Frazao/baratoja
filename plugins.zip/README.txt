HEBBO SURVIVAL v0.1 - FISICA REAL
=================================

Esta versao cria o zumbi como BOT/RoomUnit REAL do Arcturus 3.6.0.

O que ja funciona:
- zumbi existe em X/Y/Z do quarto;
- acompanha camera e zoom (nao fica colado na tela);
- usa pathfinding nativo do Arcturus;
- respeita tiles, altura e mobis bloqueadores;
- persegue o jogador mais proximo em ate 12 tiles;
- para em um tile adjacente ao jogador;
- fica em currentBots, nao em currentHabbos: NAO conta como pessoa no quarto;
- nao usa comandos;
- nao grava bots temporarios no banco.

IMPORTANTE SOBRE O VISUAL
-------------------------
Remova/desative temporariamente o antigo hebbo-zombie-test.js do client.php.
Aquele arquivo e apenas um overlay HTML e continuara colado na tela.

Nesta v0.1, o corpo fisico aparece com visual de BOT Habbo normal. O bot recebe a motto:
HB_SURVIVAL_ZOMBIE

Na proxima etapa, o Nitro React usa essa marca para trocar SOMENTE a aparencia desse bot
pelo sprite hebbo_zombie.nitro, mantendo a coordenada fisica do RoomUnit.

INSTALACAO
----------
1. Pare o Arcturus.
2. Copie HebboSurvival.jar para:
   Arcturus/plugins/
3. Ligue o Arcturus.
4. Na primeira inicializacao o plugin cria automaticamente:
   plugins/HebboSurvival.properties
5. Para testar sem comando, renomeie o quarto para algo contendo:
   Survival
   Ex.: "Survival - Teste"
6. Entre no quarto. O zumbi real deve nascer e perseguir o jogador.

Se preferir ativar por ID, edite:
plugins/HebboSurvival.properties

Exemplo:
room_ids=123
room_name_contains=

Depois reinicie o Arcturus.

Console esperado:
[HebboSurvival] Plugin carregado...
[HebboSurvival] IA/fisica auxiliar iniciada...
[HebboSurvival] Zombie fisico spawnado | room=... botId=... unitId=... x=... y=... z=...
